"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const LogTextColor_1 = require("C:/snapshot/project/obj/models/spt/logging/LogTextColor");
const ConfigTypes_1 = require("C:/snapshot/project/obj/models/enums/ConfigTypes");
const Traders_1 = require("C:/snapshot/project/obj/models/enums/Traders");
const References_1 = require("./Refs/References");
const TraderTemplate_1 = require("./Trader/TraderTemplate");
const Utils_1 = require("./Refs/Utils");
const baseJson = __importStar(require("../db/base.json"));
const modName = "GeekerTheTrader";
class TraderTemplate {
    ref = new References_1.References();
    constructor() { }
    preSptLoad(container) {
        this.ref.preSptLoad(container);
        const ragfair = this.ref.configServer.getConfig(ConfigTypes_1.ConfigTypes.RAGFAIR);
        const traderConfig = this.ref.configServer.getConfig(ConfigTypes_1.ConfigTypes.TRADER);
        const traderUtils = new Utils_1.TraderUtils();
        const traderData = new TraderTemplate_1.TraderData(traderConfig, this.ref, traderUtils);
        traderData.registerProfileImage();
        traderData.setupTraderUpdateTime();
        Traders_1.Traders[baseJson._id] = baseJson._id;
        ragfair.traders[baseJson._id] = true;
    }
    postDBLoad(container) {
        this.ref.postDBLoad(container);
        const traderConfig = this.ref.configServer.getConfig(ConfigTypes_1.ConfigTypes.TRADER);
        const traderUtils = new Utils_1.TraderUtils();
        const traderData = new TraderTemplate_1.TraderData(traderConfig, this.ref, traderUtils);
        traderData.pushTrader();
        traderData.addTraderToLocales(this.ref.tables, baseJson.name, "Geeker", baseJson.nickname, baseJson.location, "Insert massive war thunder advert here");
        this.ref.logger.log(`[${modName}] Yo yo yo its IBitePancakes,  Huge thanks to KillerDJ cause otherwise this mod wouldnt exist fr fr. This mod works for all 3.9.X versions as long as they run on patch 0.14.9.1.30626. This is not a fully done mod and will be paired with another mod on another release version :(`, LogTextColor_1.LogTextColor.YELLOW);
    }
}
module.exports = { mod: new TraderTemplate() };
//# sourceMappingURL=mod.js.map