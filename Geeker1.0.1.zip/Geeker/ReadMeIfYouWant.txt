Message:

-This mod was released on the 27th of July 2024 By IBitePancakes

Thanks to various members of the spt community for helping me throughout the start and special thanks for KillerDJ and his trader template (Yeah i used a template i js aint good wit it)

This mod isnt a full release and its half of the mod so consider it a mod meant to help early on. :)